﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp.Model
{
    public class AlreadyCertifiedModel
    {
        public String BlobID { get; set; }

        public EventModel Event { get; set; }

        public int EndEpoch { get; set; }
    }
}
