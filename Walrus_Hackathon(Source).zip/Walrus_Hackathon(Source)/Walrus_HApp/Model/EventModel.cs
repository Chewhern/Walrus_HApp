﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp.Model
{
    public class EventModel
    {
        public String TXDigest { get; set; }

        public int EventSequence { get; set; }
    }
}
