﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp
{
    public class StorageModel
    {
        public String ID { get; set; }

        public int StartEpoch { get; set; }

        public int EndEpoch { get; set; }

        public int StorageSize { get; set; }
    }
}
