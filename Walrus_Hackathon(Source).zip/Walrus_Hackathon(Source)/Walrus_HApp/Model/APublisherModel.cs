﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp.Model
{
    public class APublisherModel
    {
        public AlreadyCertifiedModel AlreadyCertified { get; set; }
    }
}
