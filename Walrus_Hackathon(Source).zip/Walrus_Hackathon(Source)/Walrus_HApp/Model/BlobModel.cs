﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp
{
    public class BlobModel
    {
        public String ID { get; set; }

        public int StoredEpoch { get; set; }

        public String BlobID { get; set; }

        public int Size { get; set; }
        
        public String ErasureCodeType { get; set; }

        public int CertifiedEpoch { get; set; }

        public StorageModel Storage { get; set; }
    }
}
