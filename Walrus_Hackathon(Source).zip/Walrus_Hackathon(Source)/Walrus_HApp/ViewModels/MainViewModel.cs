﻿namespace Walrus_HApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{
    
}
