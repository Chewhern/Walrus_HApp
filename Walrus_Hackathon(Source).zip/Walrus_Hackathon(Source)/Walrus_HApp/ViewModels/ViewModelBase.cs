﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Walrus_HApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
