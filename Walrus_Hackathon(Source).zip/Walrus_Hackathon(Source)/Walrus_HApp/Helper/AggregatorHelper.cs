﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Walrus_HApp.Helper
{
    public static class AggregatorHelper
    {
        public static async Task<Boolean> GetAndWriteFile(String BlobID,String NewFilePath) 
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://aggregator-devnet.walrus.space/v1/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.GetAsync(BlobID);
                if (response.IsSuccessStatusCode)
                {
                    var readTask = response.Content.ReadAsStreamAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    using (FileStream outputFileStream = new FileStream(NewFilePath, FileMode.Create, FileAccess.Write))
                    {
                        await Result.CopyToAsync(outputFileStream);
                    }
                }
            }
            return true;
        }

        public static async Task<String> GetStringData(String BlobID) 
        {
            String StringData = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://aggregator-devnet.walrus.space/v1/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.GetAsync(BlobID);
                if (response.IsSuccessStatusCode)
                {
                    var readTask = response.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    StringData = Result;
                }
            }
            return StringData;
        }
    }
}
