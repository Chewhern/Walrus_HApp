﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Walrus_HApp.Model;

namespace Walrus_HApp.Helper
{
    public static class UploadFileHelper
    {
        public static async Task<String> UploadFile(String FilePath) 
        {
            String BlobID = "";
            PublisherModel MyPublisherModel = new PublisherModel();
            APublisherModel MyAPublisherModel = new APublisherModel();
            using (HttpClient client = new HttpClient())
            using (var fileStream = new FileStream(FilePath, FileMode.Open, FileAccess.Read))
            {
                // Create the stream content from the file
                var fileContent = new StreamContent(fileStream);

                // Optionally set the content type (e.g., text/plain or application/octet-stream)
                fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("text/plain");

                // Send the PUT request
                var response = await client.PutAsync("https://publisher-devnet.walrus.space/v1/store?epochs=5", fileContent);

                // Ensure the request succeeded
                response.EnsureSuccessStatusCode();

                var readTask = response.Content.ReadAsStringAsync();
                readTask.Wait();

                var Result = readTask.Result;

                if (Result.Contains("newlyCreated")) 
                {
                    MyPublisherModel = JsonConvert.DeserializeObject<PublisherModel>(Result);
                    BlobID = MyPublisherModel.NewlyCreated.BlobObject.BlobID;
                }
                else 
                {
                    MyAPublisherModel = JsonConvert.DeserializeObject<APublisherModel>(Result);
                    BlobID = MyAPublisherModel.AlreadyCertified.BlobID;
                }
            }
            return BlobID;
        }

        public static async Task<String> SubmitString(String FilePath) 
        {
            String BlobID = "";
            PublisherModel MyPublisherModel = new PublisherModel();
            APublisherModel MyAPublisherModel = new APublisherModel();
            using (var client = new HttpClient())
            {
                Byte[] TestBytes = File.ReadAllBytes(FilePath);
                String TestString = Convert.ToBase64String(TestBytes);
                StringContent TestStringContent = new StringContent(TestString);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.PutAsync("https://publisher-devnet.walrus.space/v1/store", TestStringContent);
                if (response.IsSuccessStatusCode)
                {
                    var readTask = response.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    if (Result.Contains("newlyCreated"))
                    {
                        MyPublisherModel = JsonConvert.DeserializeObject<PublisherModel>(Result);
                        BlobID = MyPublisherModel.NewlyCreated.BlobObject.BlobID;
                    }
                    else
                    {
                        MyAPublisherModel = JsonConvert.DeserializeObject<APublisherModel>(Result);
                        BlobID = MyAPublisherModel.AlreadyCertified.BlobID;
                    }
                }
            }
            return BlobID;
        }
    }
}
