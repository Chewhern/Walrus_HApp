﻿using System;
using BCASodium;
using ASodium;
using Avalonia.Controls;
using System.Runtime.InteropServices;
using System.IO;
using System.Collections.Generic;
using Walrus_HApp.Helper;

namespace Walrus_HApp.Views;

public partial class MainView : UserControl
{
    private static int MainAppUIChooser;
    private static int CryptographicAppUIChooser;
    private static TextBlock[] MainAppFirstTextBlockArray = new TextBlock[] { };
    private static TextBox[] MainAppFirstTextBoxArray = new TextBox[] { };
    private static RadioButton[] MainAppFirstRadioButtonArray = new RadioButton[] { };
    private static Button[] MainAppFirstButtonArray = new Button[] { };
    private static TextBlock[] MainAppSecondTextBlockArray = new TextBlock[] { };
    private static TextBox[] MainAppSecondTextBoxArray = new TextBox[] { };
    private static Button[] MainAppSecondButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppFirstTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppFirstTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppFirstButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppSecondTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppSecondTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppSecondButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppThirdTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppThirdTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppThirdButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppFourthTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppFourthTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppFourthButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppFifthTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppFifthTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppFifthButtonArray = new Button[] { };
    private static TextBlock[] CryptographicAppSixthTextBlockArray = new TextBlock[] { };
    private static TextBox[] CryptographicAppSixthTextBoxArray = new TextBox[] { };
    private static Button[] CryptographicAppSixthButtonArray = new Button[] { };
    private static String MainAppRootFolder = "";
    private static String FileAppRootFolder = "";
    private static String FileSigningRootFolder = "";
    private static String FileSignatureRootFolder = "";
    private static String FileVerificationRootFolder = "";
    private static Boolean HasMainAppUIRendered = false;
    private static Boolean HasCryptographicAppUIRendered = false;

    //Main File
    //===
    //User ID:
    //Auth Public Key BlobID:
    //Sign Public Key BlobID:
    //Digital Signature Algorithm:
    //===

    //Sub File
    //===
    //Auth/Sign Public Key(Binary)
    //===
    public MainView()
    {
        InitializeComponent();
        MainAppInitialization();
        CryptographicAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) == true)
        {
            MainAppRootFolder = AppContext.BaseDirectory + "\\MainApp\\";
            FileAppRootFolder = AppContext.BaseDirectory + "\\OtherFiles\\";
            FileSigningRootFolder = AppContext.BaseDirectory + "\\OFiles\\";
            FileSignatureRootFolder = AppContext.BaseDirectory + "\\SignedFiles\\";
            FileVerificationRootFolder = AppContext.BaseDirectory + "\\VerifiedFiles\\";
        }
        else
        {
            MainAppRootFolder = AppContext.BaseDirectory + "/MainApp/";
            FileAppRootFolder = AppContext.BaseDirectory + "/OtherFiles/";
            FileSigningRootFolder = AppContext.BaseDirectory + "/OFiles/";
            FileSignatureRootFolder = AppContext.BaseDirectory + "/SignedFiles/";
            FileVerificationRootFolder = AppContext.BaseDirectory + "/VerifiedFiles/";
        }
        if (Directory.Exists(MainAppRootFolder) == false) 
        {
            Directory.CreateDirectory(MainAppRootFolder);
        }
        if (Directory.Exists(FileAppRootFolder) == false) 
        {
            Directory.CreateDirectory(FileAppRootFolder);
        }
        if (Directory.Exists(FileSigningRootFolder) == false) 
        {
            Directory.CreateDirectory(FileSigningRootFolder);
        }
        if (Directory.Exists(FileSignatureRootFolder) == false) 
        {
            Directory.CreateDirectory(FileSignatureRootFolder);
        }
        if (Directory.Exists(FileVerificationRootFolder) == false) 
        {
            Directory.CreateDirectory(FileVerificationRootFolder);
        }
    }

    private void MainAppInitialization() 
    {
        MainAppUIChooser = 0;
        MainAppToggleBTN1.IsCheckedChanged += MainAppToggleBTNSFunction;
        MainAppToggleBTN2.IsCheckedChanged += MainAppToggleBTNSFunction;
    }

    private void CryptographicAppInitialization() 
    {
        CryptographicAppUIChooser = 0;
        CryptographicAppToggleBTN1.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
        CryptographicAppToggleBTN2.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
        CryptographicAppToggleBTN3.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
        CryptographicAppToggleBTN4.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
        CryptographicAppToggleBTN5.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
        CryptographicAppToggleBTN6.IsCheckedChanged += CryptographicAppToggleBTNSFunction;
    }

    private void MainAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (MainAppToggleBTN1.IsChecked == true) 
        {
            MainAppToggleBTN2.IsChecked = false;
            MainAppUIChooser = 1;
        }
        else if (MainAppToggleBTN2.IsChecked == true) 
        {
            MainAppToggleBTN1.IsChecked = false;
            MainAppUIChooser = 2;
        }
        else 
        {
            MainAppResetUI();
        }
        MainAppDrawUI();
    }

    private void CryptographicAppToggleBTNSFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (CryptographicAppToggleBTN1.IsChecked == true)
        {
            CryptographicAppToggleBTN2.IsChecked = false;
            CryptographicAppToggleBTN3.IsChecked = false;
            CryptographicAppToggleBTN4.IsChecked = false;
            CryptographicAppToggleBTN5.IsChecked = false;
            CryptographicAppToggleBTN6.IsChecked = false;
            CryptographicAppUIChooser = 1;
        }
        else if (CryptographicAppToggleBTN2.IsChecked == true)
        {
            CryptographicAppToggleBTN1.IsChecked = false;
            CryptographicAppToggleBTN3.IsChecked = false;
            CryptographicAppToggleBTN4.IsChecked = false;
            CryptographicAppToggleBTN5.IsChecked = false;
            CryptographicAppToggleBTN6.IsChecked = false;
            CryptographicAppUIChooser = 2;
        }
        else if (CryptographicAppToggleBTN3.IsChecked == true)
        {
            CryptographicAppToggleBTN1.IsChecked = false;
            CryptographicAppToggleBTN2.IsChecked = false;
            CryptographicAppToggleBTN4.IsChecked = false;
            CryptographicAppToggleBTN5.IsChecked = false;
            CryptographicAppToggleBTN6.IsChecked = false;
            CryptographicAppUIChooser = 3;
        }
        else if (CryptographicAppToggleBTN4.IsChecked == true) 
        {
            CryptographicAppToggleBTN1.IsChecked = false;
            CryptographicAppToggleBTN2.IsChecked = false;
            CryptographicAppToggleBTN3.IsChecked = false;
            CryptographicAppToggleBTN5.IsChecked = false;
            CryptographicAppToggleBTN6.IsChecked = false;
            CryptographicAppUIChooser = 4;
        }
        else if(CryptographicAppToggleBTN5.IsChecked == true) 
        {
            CryptographicAppToggleBTN1.IsChecked = false;
            CryptographicAppToggleBTN2.IsChecked = false;
            CryptographicAppToggleBTN3.IsChecked = false;
            CryptographicAppToggleBTN4.IsChecked = false;
            CryptographicAppToggleBTN6.IsChecked = false;
            CryptographicAppUIChooser = 5;
        }
        else if(CryptographicAppToggleBTN6.IsChecked == true) 
        {
            CryptographicAppToggleBTN1.IsChecked = false;
            CryptographicAppToggleBTN2.IsChecked = false;
            CryptographicAppToggleBTN3.IsChecked = false;
            CryptographicAppToggleBTN4.IsChecked = false;
            CryptographicAppToggleBTN5.IsChecked = false;
            CryptographicAppUIChooser = 6;
        }
        else 
        {
            CryptographicAppResetUI();
        }
        CryptographicAppDrawUI();
    }

    private void MainAppDrawUI() 
    {
        if (MainAppUIChooser == 1) 
        {
            if (HasMainAppUIRendered == false) 
            {
                MainAppFirstTextBlockArray = new TextBlock[5];
                MainAppFirstTextBlockArray[0] = new TextBlock();
                MainAppFirstTextBlockArray[1] = new TextBlock();
                MainAppFirstTextBlockArray[2] = new TextBlock();
                MainAppFirstTextBlockArray[3] = new TextBlock();
                MainAppFirstTextBlockArray[4] = new TextBlock();
                MainAppFirstTextBlockArray[0].Text = "User ID";
                MainAppFirstTextBlockArray[1].Text = "Choose a digital signature algorithm";
                MainAppFirstTextBlockArray[2].Text = "Auth Public Key (B64)";
                MainAppFirstTextBlockArray[3].Text = "Signature Public Key (B64)";
                MainAppFirstTextBlockArray[4].Text = "Main Blob ID/Status";
                MainAppFirstTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppFirstTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppFirstTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppFirstTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppFirstTextBoxArray = new TextBox[4];
                MainAppFirstTextBoxArray[0] = new TextBox();
                MainAppFirstTextBoxArray[1] = new TextBox();
                MainAppFirstTextBoxArray[2] = new TextBox();
                MainAppFirstTextBoxArray[3] = new TextBox();
                MainAppFirstTextBoxArray[0].IsReadOnly = true;
                MainAppFirstTextBoxArray[1].IsReadOnly = true;
                MainAppFirstTextBoxArray[2].IsReadOnly = true;
                MainAppFirstTextBoxArray[3].IsReadOnly = true;
                MainAppFirstTextBoxArray[0].Height = 50;
                MainAppFirstTextBoxArray[0].Width = 370;
                MainAppFirstTextBoxArray[1].Height = 50;
                MainAppFirstTextBoxArray[1].Width = 370;
                MainAppFirstTextBoxArray[2].Height = 50;
                MainAppFirstTextBoxArray[2].Width = 370;
                MainAppFirstTextBoxArray[3].Height = 50;
                MainAppFirstTextBoxArray[3].Width = 370;
                MainAppFirstRadioButtonArray = new RadioButton[2];
                MainAppFirstRadioButtonArray[0] = new RadioButton();
                MainAppFirstRadioButtonArray[1] = new RadioButton();
                MainAppFirstRadioButtonArray[0].GroupName = "CurveTypes";
                MainAppFirstRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                MainAppFirstRadioButtonArray[0].IsChecked = true;
                MainAppFirstRadioButtonArray[1].GroupName = "CurveTypes";
                MainAppFirstRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                MainAppFirstButtonArray = new Button[1];
                MainAppFirstButtonArray[0] = new Button();
                MainAppFirstButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppFirstButtonArray[0].Content = "Create Walrus Blobs";
                MainAppFirstButtonArray[0].Click += MainAppButtonsFunction;
                MainAppRPSP.Children.Add(MainAppFirstTextBlockArray[0]);
                MainAppRPSP.Children.Add(MainAppFirstTextBoxArray[0]);
                MainAppRPSP.Children.Add(MainAppFirstTextBlockArray[1]);
                MainAppRPSP.Children.Add(MainAppFirstRadioButtonArray[0]);
                MainAppRPSP.Children.Add(MainAppFirstRadioButtonArray[1]);
                MainAppRPSP.Children.Add(MainAppFirstTextBlockArray[2]);
                MainAppRPSP.Children.Add(MainAppFirstTextBoxArray[1]);
                MainAppRPSP.Children.Add(MainAppFirstTextBlockArray[3]);
                MainAppRPSP.Children.Add(MainAppFirstTextBoxArray[2]);
                MainAppRPSP.Children.Add(MainAppFirstTextBlockArray[4]);
                MainAppRPSP.Children.Add(MainAppFirstTextBoxArray[3]);
                MainAppRPSP.Children.Add(MainAppFirstButtonArray[0]);
                HasMainAppUIRendered = true;
            }
        }
        else if(MainAppUIChooser == 2) 
        {
            if (HasMainAppUIRendered == false)
            {
                MainAppSecondTextBlockArray = new TextBlock[1];
                MainAppSecondTextBlockArray[0] = new TextBlock();
                MainAppSecondTextBlockArray[0].Text = "Login Status";
                MainAppSecondTextBlockArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppSecondTextBoxArray = new TextBox[1];
                MainAppSecondTextBoxArray[0] = new TextBox();
                MainAppSecondTextBoxArray[0].IsReadOnly = true;
                MainAppSecondTextBoxArray[0].Height = 50;
                MainAppSecondTextBoxArray[0].Width = 370;
                MainAppSecondButtonArray = new Button[1];
                MainAppSecondButtonArray[0] = new Button();
                MainAppSecondButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                MainAppSecondButtonArray[0].Content = "Login with main blob";
                MainAppSecondButtonArray[0].Click += MainAppButtonsFunction;
                MainAppRPSP.Children.Add(MainAppSecondTextBlockArray[0]);
                MainAppRPSP.Children.Add(MainAppSecondTextBoxArray[0]);
                MainAppRPSP.Children.Add(MainAppSecondButtonArray[0]);
                HasMainAppUIRendered = true;
            }
        }
        else 
        {
            MainAppResetUI();
        }
    }

    private void CryptographicAppDrawUI() 
    {
        if (CryptographicAppUIChooser == 1) 
        {
            if (HasCryptographicAppUIRendered == false) 
            {
                CryptographicAppFirstTextBlockArray = new TextBlock[2];
                CryptographicAppFirstTextBlockArray[0] = new TextBlock();
                CryptographicAppFirstTextBlockArray[1] = new TextBlock();
                CryptographicAppFirstTextBlockArray[0].Text = "What's the main blob ID?";
                CryptographicAppFirstTextBlockArray[1].Text = "Status";
                CryptographicAppFirstTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppFirstTextBoxArray = new TextBox[2];
                CryptographicAppFirstTextBoxArray[0] = new TextBox();
                CryptographicAppFirstTextBoxArray[1] = new TextBox();
                CryptographicAppFirstTextBoxArray[1].IsReadOnly = true;
                CryptographicAppFirstTextBoxArray[0].Height = 50;
                CryptographicAppFirstTextBoxArray[0].Width = 370;
                CryptographicAppFirstTextBoxArray[1].Height = 50;
                CryptographicAppFirstTextBoxArray[1].Width = 370;
                CryptographicAppFirstButtonArray = new Button[1];
                CryptographicAppFirstButtonArray[0] = new Button();
                CryptographicAppFirstButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppFirstButtonArray[0].Content = "Get Main Blob";
                CryptographicAppFirstButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppFirstTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFirstTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFirstTextBlockArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFirstTextBoxArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFirstButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else if(CryptographicAppUIChooser == 2) 
        {
            if (HasCryptographicAppUIRendered == false)
            {
                CryptographicAppSecondTextBlockArray = new TextBlock[2];
                CryptographicAppSecondTextBlockArray[0] = new TextBlock();
                CryptographicAppSecondTextBlockArray[1] = new TextBlock();
                CryptographicAppSecondTextBlockArray[0].Text = "Challenge length (Minimum 16 bytes)";
                CryptographicAppSecondTextBlockArray[1].Text = "Challenge (B64)";
                CryptographicAppSecondTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppSecondTextBoxArray = new TextBox[2];
                CryptographicAppSecondTextBoxArray[0] = new TextBox();
                CryptographicAppSecondTextBoxArray[1] = new TextBox();
                CryptographicAppSecondTextBoxArray[1].IsReadOnly = true;
                CryptographicAppSecondTextBoxArray[0].Height = 50;
                CryptographicAppSecondTextBoxArray[0].Width = 370;
                CryptographicAppSecondTextBoxArray[1].Height = 50;
                CryptographicAppSecondTextBoxArray[1].Width = 370;
                CryptographicAppSecondButtonArray = new Button[1];
                CryptographicAppSecondButtonArray[0] = new Button();
                CryptographicAppSecondButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppSecondButtonArray[0].Content = "Generate Challenge";
                CryptographicAppSecondButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppSecondTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSecondTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSecondTextBlockArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSecondTextBoxArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSecondButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else if(CryptographicAppUIChooser == 3) 
        {
            if (HasCryptographicAppUIRendered == false)
            {
                CryptographicAppThirdTextBlockArray = new TextBlock[2];
                CryptographicAppThirdTextBlockArray[0] = new TextBlock();
                CryptographicAppThirdTextBlockArray[1] = new TextBlock();
                CryptographicAppThirdTextBlockArray[0].Text = "Challenge/Data (B64)";
                CryptographicAppThirdTextBlockArray[1].Text = "Signed Challenge/Status";
                CryptographicAppThirdTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppThirdTextBoxArray = new TextBox[2];
                CryptographicAppThirdTextBoxArray[0] = new TextBox();
                CryptographicAppThirdTextBoxArray[1] = new TextBox();
                CryptographicAppThirdTextBoxArray[1].IsReadOnly = true;
                CryptographicAppThirdTextBoxArray[0].Height = 50;
                CryptographicAppThirdTextBoxArray[0].Width = 370;
                CryptographicAppThirdTextBoxArray[1].Height = 50;
                CryptographicAppThirdTextBoxArray[1].Width = 370;
                CryptographicAppThirdButtonArray = new Button[1];
                CryptographicAppThirdButtonArray[0] = new Button();
                CryptographicAppThirdButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppThirdButtonArray[0].Content = "Sign Data";
                CryptographicAppThirdButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppThirdTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppThirdTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppThirdTextBlockArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppThirdTextBoxArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppThirdButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else if(CryptographicAppUIChooser == 4) 
        {
            if (HasCryptographicAppUIRendered == false)
            {
                CryptographicAppFourthTextBlockArray = new TextBlock[1];
                CryptographicAppFourthTextBlockArray[0] = new TextBlock();
                CryptographicAppFourthTextBlockArray[0].Text = "Status";
                CryptographicAppFourthTextBoxArray = new TextBox[1];
                CryptographicAppFourthTextBoxArray[0] = new TextBox();
                CryptographicAppFourthTextBoxArray[0].IsReadOnly = true;
                CryptographicAppFourthTextBoxArray[0].Height = 150;
                CryptographicAppFourthTextBoxArray[0].Width = 370;
                CryptographicAppFourthButtonArray = new Button[1];
                CryptographicAppFourthButtonArray[0] = new Button();
                CryptographicAppFourthButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppFourthButtonArray[0].Content = "Sign Files";
                CryptographicAppFourthButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppFourthTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFourthTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFourthButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else if(CryptographicAppUIChooser == 5) 
        {
            if (HasCryptographicAppUIRendered == false)
            {
                CryptographicAppFifthTextBlockArray = new TextBlock[1];
                CryptographicAppFifthTextBlockArray[0] = new TextBlock();
                CryptographicAppFifthTextBlockArray[0].Text = "Status";
                CryptographicAppFifthTextBoxArray = new TextBox[1];
                CryptographicAppFifthTextBoxArray[0] = new TextBox();
                CryptographicAppFifthTextBoxArray[0].IsReadOnly = true;
                CryptographicAppFifthTextBoxArray[0].Height = 150;
                CryptographicAppFifthTextBoxArray[0].Width = 370;
                CryptographicAppFifthButtonArray = new Button[1];
                CryptographicAppFifthButtonArray[0] = new Button();
                CryptographicAppFifthButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppFifthButtonArray[0].Content = "Verify Signed Files";
                CryptographicAppFifthButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppFifthTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFifthTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppFifthButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else if(CryptographicAppUIChooser == 6) 
        {
            if (HasCryptographicAppUIRendered == false)
            {
                CryptographicAppSixthTextBlockArray = new TextBlock[2];
                CryptographicAppSixthTextBlockArray[0] = new TextBlock();
                CryptographicAppSixthTextBlockArray[1] = new TextBlock();
                CryptographicAppSixthTextBlockArray[0].Text = "Signed Challenge/Data (B64)";
                CryptographicAppSixthTextBlockArray[1].Text = "Status";
                CryptographicAppSixthTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppSixthTextBoxArray = new TextBox[2];
                CryptographicAppSixthTextBoxArray[0] = new TextBox();
                CryptographicAppSixthTextBoxArray[1] = new TextBox();
                CryptographicAppSixthTextBoxArray[1].IsReadOnly = true;
                CryptographicAppSixthTextBoxArray[0].Height = 50;
                CryptographicAppSixthTextBoxArray[0].Width = 370;
                CryptographicAppSixthTextBoxArray[1].Height = 50;
                CryptographicAppSixthTextBoxArray[1].Width = 370;
                CryptographicAppSixthButtonArray = new Button[1];
                CryptographicAppSixthButtonArray[0] = new Button();
                CryptographicAppSixthButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                CryptographicAppSixthButtonArray[0].Content = "Verify Signed Data/Challenge";
                CryptographicAppSixthButtonArray[0].Click += CryptographicAppButtonsFunction;
                CryptographicAppRPSP.Children.Add(CryptographicAppSixthTextBlockArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSixthTextBoxArray[0]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSixthTextBlockArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSixthTextBoxArray[1]);
                CryptographicAppRPSP.Children.Add(CryptographicAppSixthButtonArray[0]);
                HasCryptographicAppUIRendered = true;
            }
        }
        else 
        {
            CryptographicAppResetUI();
        }
    }

    private void MainAppResetUI() 
    {
        MainAppUIChooser = 0;
        HasMainAppUIRendered = false;
        MainAppFirstTextBlockArray = new TextBlock[] { };
        MainAppFirstTextBoxArray = new TextBox[] { };
        MainAppFirstRadioButtonArray = new RadioButton[] { };
        MainAppFirstButtonArray = new Button[] { };
        MainAppSecondTextBlockArray = new TextBlock[] { };
        MainAppSecondTextBoxArray = new TextBox[] { };
        MainAppSecondButtonArray = new Button[] { };
        MainAppRPSP.Children.Clear();
    }

    private void CryptographicAppResetUI() 
    {
        CryptographicAppUIChooser = 0;
        HasCryptographicAppUIRendered = false;
        CryptographicAppFirstTextBlockArray = new TextBlock[] { };
        CryptographicAppFirstTextBoxArray = new TextBox[] { };
        CryptographicAppFirstButtonArray = new Button[] { };
        CryptographicAppSecondTextBlockArray = new TextBlock[] { };
        CryptographicAppSecondTextBoxArray = new TextBox[] { };
        CryptographicAppSecondButtonArray = new Button[] { };
        CryptographicAppThirdTextBlockArray = new TextBlock[] { };
        CryptographicAppThirdTextBoxArray = new TextBox[] { };
        CryptographicAppThirdButtonArray = new Button[] { };
        CryptographicAppFourthTextBlockArray = new TextBlock[] { };
        CryptographicAppFourthTextBoxArray = new TextBox[] { };
        CryptographicAppFourthButtonArray = new Button[] { };
        CryptographicAppFifthTextBlockArray = new TextBlock[] { };
        CryptographicAppFifthTextBoxArray = new TextBox[] { };
        CryptographicAppFifthButtonArray = new Button[] { };
        CryptographicAppSixthTextBlockArray = new TextBlock[] { };
        CryptographicAppSixthTextBoxArray = new TextBox[] { };
        CryptographicAppSixthButtonArray = new Button[] { };
        CryptographicAppRPSP.Children.Clear();
    }

    private async void MainAppButtonsFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (MainAppUIChooser == 1) 
        {
            if (Directory.GetFiles(MainAppRootFolder).Length == 0) 
            {
                String UserID = CryptographicSecureIDGenerator.GenerateUniqueString();
                String DSA = "";
                String AuthPublicKeyB64 = "";
                String SignPublicKeyB64 = "";
                if (MainAppFirstRadioButtonArray[0].IsChecked == true)
                {
                    RevampedKeyPair AuthKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    RevampedKeyPair SignKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                    File.WriteAllBytes(MainAppRootFolder + "AuthPublicKey.txt", AuthKeyPair.PublicKey);
                    File.WriteAllBytes(MainAppRootFolder + "AuthPrivateKey.txt", AuthKeyPair.PrivateKey);
                    File.WriteAllBytes(MainAppRootFolder + "SignPublicKey.txt", SignKeyPair.PublicKey);
                    File.WriteAllBytes(MainAppRootFolder + "SignPrivateKey.txt", SignKeyPair.PrivateKey);
                    AuthPublicKeyB64 = Convert.ToBase64String(AuthKeyPair.PublicKey);
                    SignPublicKeyB64 = Convert.ToBase64String(SignKeyPair.PublicKey);
                    AuthKeyPair.Clear();
                    SignKeyPair.Clear();
                    DSA = "ED25519";
                }
                else
                {
                    ED448RevampedKeyPair AuthKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    ED448RevampedKeyPair SignKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                    File.WriteAllBytes(MainAppRootFolder + "AuthPublicKey.txt", AuthKeyPair.PublicKey);
                    File.WriteAllBytes(MainAppRootFolder + "AuthPrivateKey.txt", AuthKeyPair.PrivateKey);
                    File.WriteAllBytes(MainAppRootFolder + "SignPublicKey.txt", SignKeyPair.PublicKey);
                    File.WriteAllBytes(MainAppRootFolder + "SignPrivateKey.txt", SignKeyPair.PrivateKey);
                    AuthPublicKeyB64 = Convert.ToBase64String(AuthKeyPair.PublicKey);
                    SignPublicKeyB64 = Convert.ToBase64String(SignKeyPair.PublicKey);
                    AuthKeyPair.Clear();
                    SignKeyPair.Clear();
                    DSA = "ED448";
                }
                List<String> BlobIDs = new List<String>();
                String BlobID = await UploadFileHelper.UploadFile(MainAppRootFolder + "AuthPublicKey.txt");
                BlobIDs.Add(BlobID);
                BlobID = await UploadFileHelper.UploadFile(MainAppRootFolder + "SignPublicKey.txt");
                BlobIDs.Add(BlobID);
                String MainFileContent = UserID + Environment.NewLine + BlobIDs[0] + Environment.NewLine + BlobIDs[1] + Environment.NewLine + DSA;
                File.WriteAllText(MainAppRootFolder + "SimpleCert.txt", MainFileContent);
                String MBlobID = await UploadFileHelper.UploadFile(MainAppRootFolder + "SimpleCert.txt");
                File.WriteAllText(MainAppRootFolder + "SimpleCertBlobID.txt", MBlobID);
                MainAppFirstTextBoxArray[0].Text = UserID;
                MainAppFirstTextBoxArray[1].Text = AuthPublicKeyB64;
                MainAppFirstTextBoxArray[2].Text = SignPublicKeyB64;
                MainAppFirstTextBoxArray[3].Text = MBlobID;
            }
            else 
            {
                MainAppFirstTextBoxArray[3].Text = "Error: You can't have more than 1 certificate per account/application";
            }
        }
        else if(MainAppUIChooser == 2) 
        {
            if (Directory.GetFiles(MainAppRootFolder).Length > 0) 
            {
                String[] SimpleCertContent = File.ReadAllLines(MainAppRootFolder + "SimpleCert.txt");
                String AuthBlobID = SimpleCertContent[1];
                Boolean AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(AuthBlobID, MainAppRootFolder + "BlockAuthPK.txt");
                Byte[] AuthPrivateKey = File.ReadAllBytes(MainAppRootFolder + "AuthPrivateKey.txt");
                Byte[] BlockPublicKey = File.ReadAllBytes(MainAppRootFolder + "BlockAuthPK.txt");
                Byte[] Challenge = SodiumRNG.GetRandomBytes(128);
                Byte[] SignedChallenge = new Byte[] { };
                Byte[] VerifiedChallenge = new Byte[] { };
                if (AuthPrivateKey.Length == 64) 
                {
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, AuthPrivateKey, true);
                    VerifiedChallenge = SodiumPublicKeyAuth.Verify(SignedChallenge, BlockPublicKey);
                }
                else 
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Challenge, new Byte[] { }, true);
                    VerifiedChallenge = SecureED448.GetMessageFromSignatureMessage(BlockPublicKey, SignedChallenge, new Byte[] { });
                }
                SodiumHelper.Sodium_Memory_Compare(Challenge, VerifiedChallenge);
                MainAppSecondTextBoxArray[0].Text = "Success: You are now logged in";
                File.Delete(MainAppRootFolder + "BlockAuthPK.txt");
            }
            else 
            {
                MainAppSecondTextBoxArray[0].Text = "Error: You haven't create an account";
            }
        }
    }

    private async void CryptographicAppButtonsFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (CryptographicAppUIChooser == 1) 
        {
            String MBlobID = CryptographicAppFirstTextBoxArray[0].Text;
            Boolean AbleToWriteFile = true;
            if(MBlobID!=null && MBlobID.CompareTo("") != 0) 
            {
                AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(MBlobID, FileAppRootFolder + "OSimpleCert.txt");
                String[] OSimpleCertContents = File.ReadAllLines(FileAppRootFolder + "OSimpleCert.txt");
                if (OSimpleCertContents.Length != 4) 
                {
                    CryptographicAppFirstTextBoxArray[1].Text = "Error: This file is not certificate format file";
                }
                else 
                {
                    File.WriteAllText(FileAppRootFolder + "OSimpleCertBlobID.txt", MBlobID);
                    AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(OSimpleCertContents[1], FileAppRootFolder + "OAuthPublicKey.txt");
                    AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(OSimpleCertContents[2], FileAppRootFolder + "OSignPublicKey.txt");
                    CryptographicAppFirstTextBoxArray[1].Text = "Certificate blob ID had been fetched and its contents were downloaded";
                }
            }
            else 
            {
                CryptographicAppFirstTextBoxArray[1].Text = "Error: Please input a main Blob ID";
            }
        }
        else if(CryptographicAppUIChooser == 2) 
        {
            String ChallengeLengthString = CryptographicAppSecondTextBoxArray[0].Text;
            if(ChallengeLengthString!=null && ChallengeLengthString.CompareTo("") != 0) 
            {
                int ChallengeLength = 0;
                Boolean AbleToParse = true;
                try
                {
                    ChallengeLength = int.Parse(ChallengeLengthString);
                }
                catch 
                {
                    AbleToParse = false;
                }
                if (AbleToParse) 
                {
                    if (ChallengeLength >= 16) 
                    {
                        Byte[] Challenge = SodiumRNG.GetRandomBytes(ChallengeLength);
                        CryptographicAppSecondTextBoxArray[1].Text = Convert.ToBase64String(Challenge);
                    }
                    else 
                    {
                        CryptographicAppSecondTextBoxArray[1].Text = "Error: The minimum challenge length is 16 bytes";
                    }
                }
                else 
                {
                    CryptographicAppSecondTextBoxArray[1].Text = "Error: Please input a valid integer(round number)";
                }
            }
            else 
            {
                CryptographicAppSecondTextBoxArray[1].Text = "Error: Please input some data";
            }
        }
        else if(CryptographicAppUIChooser == 3) 
        {
            String Base64DataString = CryptographicAppThirdTextBoxArray[0].Text;
            Boolean AbleToWriteFile = true;
            if (Base64DataString!=null && Base64DataString.CompareTo("") != 0) 
            {
                Byte[] Base64Data = new Byte[] { };
                Boolean AbleToConvert = true;
                try
                {
                    Base64Data = Convert.FromBase64String(Base64DataString);
                }
                catch 
                {
                    AbleToConvert = false;
                }
                if (AbleToConvert) 
                {
                    if (Directory.GetFiles(MainAppRootFolder).Length > 0)
                    {
                        String[] SimpleCertContent = File.ReadAllLines(MainAppRootFolder + "SimpleCert.txt");
                        String AuthBlobID = SimpleCertContent[1];
                        AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(AuthBlobID, MainAppRootFolder + "BlockAuthPK.txt");
                        Byte[] AuthPrivateKey = File.ReadAllBytes(MainAppRootFolder + "AuthPrivateKey.txt");
                        Byte[] BlockPublicKey = File.ReadAllBytes(MainAppRootFolder + "BlockAuthPK.txt");
                        Byte[] Challenge = SodiumRNG.GetRandomBytes(128);
                        Byte[] SignedChallenge = new Byte[] { };
                        Byte[] VerifiedChallenge = new Byte[] { };
                        if (AuthPrivateKey.Length == 64)
                        {
                            SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, AuthPrivateKey);
                            VerifiedChallenge = SodiumPublicKeyAuth.Verify(SignedChallenge, BlockPublicKey);
                        }
                        else
                        {
                            SignedChallenge = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Challenge, new Byte[] { });
                            VerifiedChallenge = SecureED448.GetMessageFromSignatureMessage(BlockPublicKey, SignedChallenge, new Byte[] { });
                        }
                        SodiumHelper.Sodium_Memory_Compare(Challenge, VerifiedChallenge);
                        Byte[] SignedBase64Data = new Byte[] { };
                        Byte[] VerifiedBase64Data = new Byte[] { };
                        if (AuthPrivateKey.Length == 64) 
                        {
                            SignedBase64Data = SodiumPublicKeyAuth.Sign(Base64Data,AuthPrivateKey, true);
                            VerifiedBase64Data = SodiumPublicKeyAuth.Verify(SignedBase64Data, BlockPublicKey);
                        }
                        else 
                        {
                            SignedBase64Data = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Base64Data, new Byte[] { }, true);
                            VerifiedBase64Data = SecureED448.GetMessageFromSignatureMessage(BlockPublicKey, SignedBase64Data, new Byte[] { });
                        }
                        SodiumHelper.Sodium_Memory_Compare(Base64Data, VerifiedBase64Data);
                        CryptographicAppThirdTextBoxArray[1].Text = Convert.ToBase64String(SignedBase64Data);
                    }
                    else
                    {
                        CryptographicAppThirdTextBoxArray[1].Text = "Error: You haven't create an account";
                    }
                }
                else 
                {
                    CryptographicAppThirdTextBoxArray[1].Text = "Error: Please input valid base64 encoded data";
                }
            }
            else 
            {
                CryptographicAppThirdTextBoxArray[1].Text = "Error: Please input some data";
            }
        }
        else if(CryptographicAppUIChooser == 4) 
        {
            Boolean AbleToWriteFile = true;
            if (Directory.GetFiles(MainAppRootFolder).Length > 0)
            {
                String[] SimpleCertContent = File.ReadAllLines(MainAppRootFolder + "SimpleCert.txt");
                String AuthBlobID = SimpleCertContent[1];
                AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(AuthBlobID, MainAppRootFolder + "BlockAuthPK.txt");
                Byte[] AuthPrivateKey = File.ReadAllBytes(MainAppRootFolder + "AuthPrivateKey.txt");
                Byte[] BlockPublicKey = File.ReadAllBytes(MainAppRootFolder + "BlockAuthPK.txt");
                Byte[] Challenge = SodiumRNG.GetRandomBytes(128);
                Byte[] SignedChallenge = new Byte[] { };
                Byte[] VerifiedChallenge = new Byte[] { };
                if (AuthPrivateKey.Length == 64)
                {
                    SignedChallenge = SodiumPublicKeyAuth.Sign(Challenge, AuthPrivateKey, true);
                    VerifiedChallenge = SodiumPublicKeyAuth.Verify(SignedChallenge, BlockPublicKey);
                }
                else
                {
                    SignedChallenge = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Challenge, new Byte[] { }, true);
                    VerifiedChallenge = SecureED448.GetMessageFromSignatureMessage(BlockPublicKey, SignedChallenge, new Byte[] { });
                }
                SodiumHelper.Sodium_Memory_Compare(Challenge, VerifiedChallenge);
                File.Delete(MainAppRootFolder + "BlockAuthPK.txt");
                AbleToWriteFile = await AggregatorHelper.GetAndWriteFile(SimpleCertContent[2], FileAppRootFolder + "BlockSignPK.txt");
                Byte[] ABlockPublicKey = File.ReadAllBytes(FileAppRootFolder + "BlockSignPK.txt");
                Byte[] SignPrivateKey = File.ReadAllBytes(MainAppRootFolder + "SignPrivateKey.txt");
                String[] FilesToBeSigned = Directory.GetFiles(FileSigningRootFolder);
                int Loop = 0;
                Byte[] FileContent = new Byte[] { };
                Byte[] SignedFileContent = new Byte[] { };
                Byte[] VerifiedFileContent = new Byte[] { };
                Boolean AbleToSignAll = true;
                while (Loop < FilesToBeSigned.Length) 
                {
                    try
                    {
                        FileContent = File.ReadAllBytes(FilesToBeSigned[Loop]);
                        if (SignPrivateKey.Length == 64)
                        {
                            SignedFileContent = SodiumPublicKeyAuth.Sign(FileContent, SignPrivateKey);
                            VerifiedFileContent = SodiumPublicKeyAuth.Verify(SignedFileContent, ABlockPublicKey);
                        }
                        else
                        {
                            SignedFileContent = SecureED448.GenerateSignatureMessage(SignPrivateKey, FileContent, new Byte[] { });
                            VerifiedFileContent = SecureED448.GetMessageFromSignatureMessage(ABlockPublicKey, SignedFileContent, new Byte[] { });
                        }
                        FileInfo MyFileInfo = new FileInfo(FilesToBeSigned[Loop]);
                        SodiumHelper.Sodium_Memory_Compare(FileContent, VerifiedFileContent);
                        File.WriteAllBytes(FileSignatureRootFolder + "S" + MyFileInfo.Name, SignedFileContent);
                    }
                    catch 
                    {
                        AbleToSignAll = false;
                        break;
                    }
                    Loop += 1;
                }
                SodiumSecureMemory.SecureClearBytes(SignPrivateKey);
                File.Delete(FileAppRootFolder + "BlockSignPK.txt");
                if (AbleToSignAll) 
                {
                    CryptographicAppFourthTextBoxArray[0].Text = "You have successfully signed all files";
                }
                else 
                {
                    CryptographicAppFourthTextBoxArray[0].Text = "Error: Unable to sign all files";
                }
            }
            else
            {
                CryptographicAppFourthTextBoxArray[0].Text = "Error: You haven't create an account";
            }
        }
        else if(CryptographicAppUIChooser == 5) 
        {
            if (Directory.GetFiles(FileAppRootFolder).Length > 0) 
            {
                Byte[] OtherUserSignPK = File.ReadAllBytes(FileAppRootFolder + "OSignPublicKey.txt");
                String[] FilesToBeVerified = Directory.GetFiles(FileSignatureRootFolder);
                int Loop = 0;
                Boolean AbleToVerifyAll = true;
                Byte[] SignedFileContent = new Byte[] { };
                Byte[] VerifiedFileContent = new Byte[] { };
                while (Loop < FilesToBeVerified.Length) 
                {
                    try
                    {
                        SignedFileContent = File.ReadAllBytes(FilesToBeVerified[Loop]);
                        if (OtherUserSignPK.Length == 32) 
                        {
                            VerifiedFileContent = SodiumPublicKeyAuth.Verify(SignedFileContent,OtherUserSignPK);
                        }
                        else 
                        {
                            VerifiedFileContent = SecureED448.GetMessageFromSignatureMessage(OtherUserSignPK,SignedFileContent,new Byte[] { });
                        }
                        FileInfo MyFileInfo = new FileInfo(FilesToBeVerified[Loop]);
                        String ActualFileName = MyFileInfo.Name.Substring(1,MyFileInfo.Name.Length-1);
                        ActualFileName = "V" + ActualFileName;
                        File.WriteAllBytes(FileVerificationRootFolder+ActualFileName, VerifiedFileContent);
                    }
                    catch 
                    {
                        AbleToVerifyAll = false;
                    }
                    Loop += 1;
                }
                if (AbleToVerifyAll) 
                {
                    CryptographicAppFifthTextBoxArray[0].Text = "You have successfully verified all signed files";
                }
                else 
                {
                    CryptographicAppFifthTextBoxArray[0].Text = "Error: Some/All files can't be verified with given other user's signature public key";
                }
            }
            else 
            {
                CryptographicAppFifthTextBoxArray[0].Text = "Error: You haven't fetch another user's certificate";
            }
        }
        else if(CryptographicAppUIChooser == 6) 
        {
            String Base64DataString = CryptographicAppSixthTextBoxArray[0].Text;
            if (Base64DataString != null && Base64DataString.CompareTo("") != 0)
            {
                Byte[] Base64Data = new Byte[] { };
                Boolean AbleToConvert = true;
                try
                {
                    Base64Data = Convert.FromBase64String(Base64DataString);
                }
                catch
                {
                    AbleToConvert = false;
                }
                if (AbleToConvert)
                {
                    if (Directory.GetFiles(FileAppRootFolder).Length > 0)
                    {
                        Byte[] OtherUserAuthPublicKey = File.ReadAllBytes(FileAppRootFolder + "OAuthPublicKey.txt");
                        Byte[] VerifiedBase64Data = new Byte[] { };
                        if (OtherUserAuthPublicKey.Length == 32) 
                        {
                            VerifiedBase64Data = SodiumPublicKeyAuth.Verify(Base64Data, OtherUserAuthPublicKey);
                        }
                        else 
                        {
                            VerifiedBase64Data = SecureED448.GetMessageFromSignatureMessage(OtherUserAuthPublicKey, Base64Data, new Byte[] { });
                        }
                        CryptographicAppSixthTextBoxArray[1].Text = "Signed Challenge/Base64 data have been verified";
                    }
                    else
                    {
                        CryptographicAppSixthTextBoxArray[1].Text = "Error: You haven't fetch another user's certificate";
                    }
                }
                else
                {
                    CryptographicAppSixthTextBoxArray[1].Text = "Error: Please input valid base64 encoded data";
                }
            }
            else
            {
                CryptographicAppSixthTextBoxArray[1].Text = "Error: Please input some data";
            }
        }
    }
}
