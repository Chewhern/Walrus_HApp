﻿using Avalonia.Controls;

namespace Walrus_HApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
